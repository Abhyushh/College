package com.example.doubt_out


import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    
}
