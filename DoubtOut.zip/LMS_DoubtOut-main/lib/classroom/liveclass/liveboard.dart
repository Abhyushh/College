// import 'package:flutter/material.dart';

// class LiveBoard extends CustomPainter {
//   @override
//   void paint(Canvas canvas, Size size) {
//     print(size);
//     var paint = Paint();
//     paint.color = Colors.red;
//     paint.strokeWidth = 5;
//     for (double i = 0; i <= 200; i++) {
//       canvas.drawLine(
//         Offset(i, size.height),
//         Offset(size.width, size.height / 2),
//         paint,
//       );
//     }
//   }

//   @override
//   bool shouldRepaint(CustomPainter oldDelegate) {
//     return false;
//   }
// }

